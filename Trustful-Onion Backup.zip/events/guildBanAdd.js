const Database = require('odb.json');
const db = new Database.Database('./Database', {
    file: 'Data.json',
    cli: false,
    deep: true
});
module.exports = (client, ban) => {
    console.log(`${ban.user.id} was banned from the server.`);
    
}